﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameWork
{
    public interface Icollosion
    {
        void PerformAction(Igame game , GameObject g1 , GameObject g2);
    }
}
